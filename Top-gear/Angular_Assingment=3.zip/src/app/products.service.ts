import { Products } from './products';
import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {
  baseUrl='http://localhost:3000';
  getProductsData()
  {
    return this.http.get<Products[]>(this.baseUrl+'/products');
  }
  constructor(private http: HttpClient) { }
}
