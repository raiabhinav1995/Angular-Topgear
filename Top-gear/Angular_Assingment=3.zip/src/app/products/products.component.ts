import { ProductsService } from './../products.service';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {Products} from '../products';
@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  @Input('company')
  company="";
  products:Products[]=[];
  name="abhi";
  quantity=10;
  @Output() sendData=new EventEmitter();
  constructor(private prodService: ProductsService)
  {
    this.initialiseProducts();
    //console.log(res.json());
  }
  async initialiseProducts()
  {
    await this.prodService.getProductsData().subscribe(products=>
      {
        //console.log(products);
        this.products=products as Products[];
        //console.log("Products got is"+ this.products);

      });
  }
  addToProducts(name, quantity)
  {
    let p=new Products(name, quantity);
    console.log(this.name, this.quantity);
    this.products.push(p);
    this.sendData.emit(p);
  }

  ngOnInit() {
  }

}
