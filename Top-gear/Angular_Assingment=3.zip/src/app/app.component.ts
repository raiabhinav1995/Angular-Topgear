import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  company="Amazon";
  name="";
  allow=false;
  quantity=1;
  title = 'Angular-Demo';

  eventHandler(event)
  {
    this.name=event.name;
    this.quantity=event.quantity;
    this.allow=true;

  }
}
