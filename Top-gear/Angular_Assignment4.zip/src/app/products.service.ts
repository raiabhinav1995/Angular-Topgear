import { Products } from './products';
import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {
  baseUrl='http://localhost:3000';
  products=[];
  getProductsData()
  {
    return this.http.get<Products[]>(this.baseUrl+'/products');
  }
  async initialiseProducts()
  {
    await this.getProductsData().subscribe
    (
      products=>
      {
        this.products=products;
        console.log(this.products);
      }
    )
    return this.products;
  }
  constructor(private http: HttpClient) { }
}
