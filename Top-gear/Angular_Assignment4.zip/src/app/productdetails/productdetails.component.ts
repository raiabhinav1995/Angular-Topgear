import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Products } from '../products';
import { ProductsService } from '../products.service';
import { Location } from '@angular/common';
@Component({
  selector: 'app-productdetails',
  templateUrl: './productdetails.component.html',
  styleUrls: ['./productdetails.component.css']
})
export class ProductdetailsComponent{
  product:Products;
  //loc:Location;
  products:Products[]=[];
  id;
  //sub;
  constructor(private _Activatedroute:ActivatedRoute,
    private _router:Router,
    private _productService:ProductsService, private loc:Location)
  {
    this.initialiseProducts();
    //this.returnId();

  }
  async initialiseProducts()
  {
    await this._productService.getProductsData().subscribe
    (
      products=>
      {
        this.products=products as Products[];
        console.log(this.products);
        this.product=this.returnId();
        //return this.products;
      }
    )
    //return this.products;
  }
  returnId()
  {
    this.id=this._Activatedroute.snapshot.params['id'];
    console.log(this.id, this.products[0]);
    //let products=<Products[]>this._productService.getProductsData();
    //this.product=products.find(p => p.productID==this.id);
    for(let i=0;i<this.products.length;i++)
    {
      console.log(this.products[i]['name']);
      if(this.products[i]['name']===this.id)
      {
        return this.id;
      }
    }
  }
  goBack()
  {
    //let loc:Location;
    this.loc.back();
  }
}
