export class Products
{
constructor(private name: string, private quantity: number)
{
  this.name=name;
  this.quantity=quantity;
}
}
