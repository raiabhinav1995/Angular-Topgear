import { Component, OnInit } from '@angular/core';
import {Products} from '../products';
@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  products:Products[]=[];
  name="abhi";
  quantity=10;
  constructor()
  {
    this.products=
    [
      new Products('Justin Bieber',50),
      new Products('Fridge',10),
      new Products('TV',10)

    ];
  }
  addToProducts(name, quantity)
  {
    console.log(this.name, this.quantity);
    this.products.push(new Products(name, quantity));
  }

  ngOnInit() {
  }

}
